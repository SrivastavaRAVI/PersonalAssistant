# personal_assistant_for_desktop
Personal Assistant for Desktop - Python Project
