import the_voice
the_voice.say_and_print("My voice is little bit electronic,")   
the_voice.say_and_print("but it always sounds good to say, thank you")   